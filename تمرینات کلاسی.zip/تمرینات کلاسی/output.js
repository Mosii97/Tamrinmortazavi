var number1=25 +3;
document.write(number1+"<br>");
var name1 ="Hi " + "hosein"+"<br>"+"</br>";
document.write(name1);
var number2=21;
var number3=30;

document.write("<br>" +number2>number3)
document.write("<br></br>")
document.write(+number2<number3)
document.write("<br></br>")
document.write((number2=>34)||!(number3==48));

function dalli(){
    alert("hiiiiiiiiii!");
}dalli();

function dolar(x){

    document.write(x);
}

//var temp = 'hosein';
//dolar(temp);
 var num  = [10,12,13,14,15,16];

 //alert(num.length);
//document.getElementById('num').innerHTML = num; 

const time = new Date().getHours() ;

let happy ;

if( time <= 10 && time>6)
{
 happy="goodmorning";
 }
 else if(time >= 17)
 {
 happy ="goodafternoon";
 }
else if (time >= 24)
 {
 happy ="goodnight";
 }
 else{
     happy ='boro bekap';
 }



 document.getElementById('ali').innerHTML=happy; 
//const time = new Date().getHours();
//let greeting;
//if (time < 10) {
  //greeting = "Good morning";
//} else if (time < 18) {
  //greeting = "Good day";
//} else {
  //greeting = "Good evening";
//}
//document.getElementById("ali").innerHTML =greeting;